# Проверка визуального артефакта

Проверка ограничена статическим рендером. Браузерное и функциональное end-to-end тестирование не проводилось; prototype не заявляется готовым к production.

Для статического рендера использованы WeasyPrint и PyMuPDF для PDF→PNG. Шрифты включены локально. Статический DOM экспортируется из данных макета; JS не исполняется рендерером.

Практические особенности:
- `@page {size:390px 844px!important;margin:0}`. User stylesheet без important может проиграть авторскому @page.
- Inline SVG должны иметь явные fill/stroke/stroke-width/width/height. Вложенный CSS currentColor наследуется иначе, чем браузером.
- Min-height у inline-flex может требовать явного height для print proof.
- Длинные layouts сначала рендерятся в fullstate на достаточной высоте; viewport PNG создается через clip. Текст ниже viewport обязан существовать в fullstate или scrollable HTML.
- CSS media width не является браузерной эмуляцией. Для mobile proof breakpoint выбирается явно и это честно указывается.
- Просмотр PNG и проверка полноты текста PDF дополняют статическую проверку links/assets/routes; они не заменяют interaction testing.

Публичные proof имеют запись о методе в public/qa_public.json. Такие служебные сведения входят в handoff и не должны скрываться под обещанием production readiness.
