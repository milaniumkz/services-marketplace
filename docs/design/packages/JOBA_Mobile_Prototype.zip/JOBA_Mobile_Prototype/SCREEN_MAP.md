# JOBA - карта экранов этого архива

42 полных вертикальных PNG находятся в отдельном JOBA_Mobile_Full_Screens.zip. Все пути ниже относятся к этому самостоятельному прототипу.

| ID | Экран | PNG | HTML | Prototype |
|---|---|---|---|---|
| S01 | Старт и регион | mobile/screens/S01-welcome.png | mobile/static/S01-welcome.html | mobile/index.html#welcome |
| S02 | Регистрация и вход | mobile/screens/S02-login.png | mobile/static/S02-login.html | mobile/index.html#login |
| S03 | Условия | mobile/screens/S03-terms.png | mobile/static/S03-terms.html | mobile/index.html#terms |
| S04 | Первичный профиль | mobile/screens/S04-onboarding.png | mobile/static/S04-onboarding.html | mobile/index.html#onboarding |
| S05 | Выбор доступа | mobile/screens/S05-access.png | mobile/static/S05-access.html | mobile/index.html#access |
| S06 | Главная заказчика | mobile/screens/S06-home.png | mobile/static/S06-home.html | mobile/index.html#home |
| S07 | Поиск исполнителей | mobile/screens/S07-catalog.png | mobile/static/S07-catalog.html | mobile/index.html#catalog |
| S08 | Карточка исполнителя | mobile/screens/S08-contractor.png | mobile/static/S08-contractor.html | mobile/index.html#contractor |
| S09 | Главная исполнителя | mobile/screens/S09-executor-home.png | mobile/static/S09-executor-home.html | mobile/index.html#executor-home |
| S10 | Карточка заказа | mobile/screens/S10-order.png | mobile/static/S10-order.html | mobile/index.html#order |
| S11 | Мой профиль | mobile/screens/S11-account.png | mobile/static/S11-account.html | mobile/index.html#account |
| S12 | Услуги исполнителя | mobile/screens/S12-services.png | mobile/static/S12-services.html | mobile/index.html#services |
| S13 | Документ исполнителя | mobile/screens/S13-verification.png | mobile/static/S13-verification.html | mobile/index.html#verification |
| S14 | Отзывы пользователя | mobile/screens/S14-reviews.png | mobile/static/S14-reviews.html | mobile/index.html#reviews |
| S15 | Безопасность | mobile/screens/S15-security.png | mobile/static/S15-security.html | mobile/index.html#security |
| S16 | Черновик заказа | mobile/screens/S16-create.png | mobile/static/S16-create.html | mobile/index.html#create |
| S17 | Публикация | mobile/screens/S17-publish.png | mobile/static/S17-publish.html | mobile/index.html#publish |
| S18 | Мои заказы | mobile/screens/S18-orders.png | mobile/static/S18-orders.html | mobile/index.html#orders |
| S19 | Приглашение исполнителю | mobile/screens/S19-invite.png | mobile/static/S19-invite.html | mobile/index.html#invite |
| S20 | Входящие приглашения | mobile/screens/S20-invitations.png | mobile/static/S20-invitations.html | mobile/index.html#invitations |
| S21 | Отклик | mobile/screens/S21-offer.png | mobile/static/S21-offer.html | mobile/index.html#offer |
| S22 | Список откликов | mobile/screens/S22-offers.png | mobile/static/S22-offers.html | mobile/index.html#offers |
| S23 | Выбор исполнителя | mobile/screens/S23-select-contractor.png | mobile/static/S23-select-contractor.html | mobile/index.html#select-contractor |
| S24 | Рабочий заказ | mobile/screens/S24-work.png | mobile/static/S24-work.html | mobile/index.html#work |
| S25 | Чат | mobile/screens/S25-chat.png | mobile/static/S25-chat.html | mobile/index.html#chat |
| S26 | Завершение | mobile/screens/S26-complete.png | mobile/static/S26-complete.html | mobile/index.html#complete |
| S27 | Отмена | mobile/screens/S27-cancel.png | mobile/static/S27-cancel.html | mobile/index.html#cancel |
| S28 | Оценка | mobile/screens/S28-review.png | mobile/static/S28-review.html | mobile/index.html#review |
| S29 | Жалоба | mobile/screens/S29-report.png | mobile/static/S29-report.html | mobile/index.html#report |
| S30 | Мои обращения | mobile/screens/S30-cases.png | mobile/static/S30-cases.html | mobile/index.html#cases |
| S31 | Уведомления | mobile/screens/S31-notifications.png | mobile/static/S31-notifications.html | mobile/index.html#notifications |
| S32 | Мой доступ | mobile/screens/S32-my-access.png | mobile/static/S32-my-access.html | mobile/index.html#my-access |
| S33 | Рекламная награда | mobile/screens/S33-reward.png | mobile/static/S33-reward.html | mobile/index.html#reward |
| S34 | Приватность | mobile/screens/S34-privacy.png | mobile/static/S34-privacy.html | mobile/index.html#privacy |
| S35 | Настройки | mobile/screens/S35-settings.png | mobile/static/S35-settings.html | mobile/index.html#settings |
| S36 | Локальная разблокировка | mobile/screens/S36-unlock.png | mobile/static/S36-unlock.html | mobile/index.html#unlock |
| S37 | Приглашения и бонусы | mobile/screens/S37-referrals.png | mobile/static/S37-referrals.html | mobile/index.html#referrals |
| S38 | Мое портфолио | mobile/screens/S38-portfolio.png | mobile/static/S38-portfolio.html | mobile/index.html#portfolio |
| S39 | Проект и фото | mobile/screens/S39-portfolio-project.png | mobile/static/S39-portfolio-project.html | mobile/index.html#portfolio-project |
| S40 | Поддержка и recovery chat | mobile/screens/S40-support.png | mobile/static/S40-support.html | mobile/index.html#support |
| S41 | Топ-100 | mobile/screens/S41-top.png | mobile/static/S41-top.html | mobile/index.html#top |
| S42 | Продвинуть объявление | mobile/screens/S42-promotion.png | mobile/static/S42-promotion.html | mobile/index.html#promotion |
