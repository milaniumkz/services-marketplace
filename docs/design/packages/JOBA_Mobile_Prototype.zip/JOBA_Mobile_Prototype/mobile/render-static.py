from weasyprint import HTML
from pathlib import Path
import fitz,sys,json
root=Path(__file__).parent
files=sorted((root/'static').glob('*.html'))
if len(sys.argv)>1: files=[p for p in files if p.stem.split('-',1)[1] in sys.argv[1:]]
report=[]
for p in files:
 pdf=HTML(filename=str(p),media_type='screen').write_pdf()
 d=fitz.open(stream=pdf,filetype='pdf')
 pix=d[0].get_pixmap(matrix=fitz.Matrix(2*96/72,2*96/72),alpha=False,clip=fitz.Rect(0,0,390*72/96,844*72/96))
 out=root/'screens'/(p.stem+'.png');pix.save(out)
 report.append({'screen':p.stem,'pages':len(d),'renderer':'WeasyPrint static DOM, not browser','size':[pix.width,pix.height]})
print(json.dumps(report))
(root/'static-render-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
