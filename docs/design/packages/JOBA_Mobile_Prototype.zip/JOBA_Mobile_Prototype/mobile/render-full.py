from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import json,re,sys
root=Path(__file__).parent
r=json.loads((root/'routes.json').read_text())
files=[root/'static'/(x['spec']+'-'+x['id']+'.html') for x in r if x['spec'] in [f'S{i:02}' for i in range(1,43)]]
if len(sys.argv)>1:files=[p for p in files if p.stem.split('-',1)[1] in sys.argv[1:]]
(root/'full-screens').mkdir(exist_ok=True)
def boxes(b):
 yield b
 if hasattr(b,'_box'):yield from boxes(b._box)
 else:
  for ch in b.all_children():yield from boxes(ch)
def work(p):
 from weasyprint import HTML
 import fitz
 s=p.read_text();over='<style>.phone{height:4000px;max-height:none}.scroll{max-height:none!important;height:auto!important;bottom:auto!important;overflow:visible!important}</style>'
 draft=HTML(string=s+over,base_url=str(p.parent),media_type='screen').render()
 main=next(b for b in boxes(draft.pages[0]._page_box) if b.element is not None and b.element.tag=='main' and not hasattr(b,'_box'))
 bottom=94 if 'class="composer"' in s else 91 if 'class="sticky-actions"' in s else 83 if 'class="nav"' in s else 22
 height=max(844,round(main.position_y+main.height+bottom+1))
 final=over+f'<style>@page{{size:390px {height}px!important}}html,body{{height:{height}px}}.phone{{height:{height}px;max-height:none}}</style>'
 pdf=HTML(string=s+final,base_url=str(p.parent),media_type='screen').write_pdf()
 d=fitz.open(stream=pdf,filetype='pdf');pix=d[0].get_pixmap(matrix=fitz.Matrix(8/3,8/3),alpha=False);pix.save(root/'full-screens'/(p.stem+'-full.png'))
 return {'screen':p.stem,'full_css_height':height,'content_css_height':round(main.height),'rendered_pixels':[pix.width,pix.height]}
if __name__=='__main__':
 with ProcessPoolExecutor(max_workers=6) as ex:result=list(ex.map(work,files))
 reportpath=root/'full-render-report.json'
 if len(sys.argv)>1 and reportpath.exists():
  previous=json.loads(reportpath.read_text());updated={x['screen']:x for x in result};result=[updated.pop(x['screen'],x) for x in previous]+list(updated.values())
 reportpath.write_text(json.dumps(result,ensure_ascii=False,indent=2));print('Full-state:',len(result))
