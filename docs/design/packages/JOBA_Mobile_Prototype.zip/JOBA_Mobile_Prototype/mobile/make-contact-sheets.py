from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json,math
root=Path(__file__).parent;out=root/'contact-sheets';out.mkdir(exist_ok=True)
r=json.loads((root/'routes.json').read_text());main=sorted([x for x in r if x['spec'] in [f'S{i:02}' for i in range(1,43)]],key=lambda x:x['spec']);extra=[x for x in r if x.get('png') and x not in main]
f=ImageFont.truetype(str(root/'assets/NotoSans-Bold.ttf'),18);sm=ImageFont.truetype(str(root/'assets/NotoSans-Regular.ttf'),12)
for group,name,batch in [(main,'main',12),(extra,'states',16)]:
 for start in range(0,len(group),batch):
  frames=group[start:start+batch];cols=4;w=244;h=528;gap=24;top=75;rows=math.ceil(len(frames)/cols);im=Image.new('RGB',(cols*(w+gap)+gap,top+rows*(h+58)+gap),'#E8EDF5');d=ImageDraw.Draw(im);d.text((gap,20),f'JOBA / MOBILE · {name.upper()} {start+1}–{start+len(frames)}',font=f,fill='#172B4D')
  for i,r in enumerate(frames):
   x=gap+(i%cols)*(w+gap);y=top+(i//cols)*(h+58);a=Image.open(root/r['png']).resize((w,h),Image.Resampling.LANCZOS);im.paste(a,(x,y));d.text((x,y+h+10),r['spec']+' · '+r['title'][:28],font=sm,fill='#172B4D')
  im.save(out/f'{name}-{start//batch+1:02}.png')
print(len(main),'main',len(extra),'extra')
