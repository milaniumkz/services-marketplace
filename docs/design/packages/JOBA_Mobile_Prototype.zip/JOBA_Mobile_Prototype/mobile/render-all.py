from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import json,os
root=Path(__file__).parent
files=sorted((root/'static').glob('*.html'))
def work(p):
 from weasyprint import HTML
 import fitz
 doc=HTML(filename=str(p),media_type='screen').render()
 overflow=[]
 def visit(b,anc=()):
  e=b.element;c=e.get('class','') if e is not None else '';a=anc+(c,)
  if type(b).__name__=='TextBox' and (b.position_x<-1 or b.position_x+b.width>391) and not any('chips' in x or 'hero-art' in x for x in a):overflow.append({'text':b.text[:60],'x':round(b.position_x,1),'right':round(b.position_x+b.width,1)})
  if hasattr(b,'_box'):visit(b._box,a)
  else:
   for ch in b.all_children():visit(ch,a)
 visit(doc.pages[0]._page_box)
 pdf=doc.write_pdf(); d=fitz.open(stream=pdf,filetype='pdf')
 pix=d[0].get_pixmap(matrix=fitz.Matrix(8/3,8/3),alpha=False,clip=fitz.Rect(0,0,292.5,633))
 pix.save(root/'screens'/(p.stem+'.png'))
 return {'screen':p.stem,'pages':len(d),'size':[pix.width,pix.height],'renderer':'WeasyPrint static DOM viewport; not browser QA','text_overflow':overflow}
if __name__=='__main__':
 with ProcessPoolExecutor(max_workers=6) as ex: results=list(ex.map(work,files))
 (root/'static-render-report.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print(f'Rendered {len(results)} screens')
