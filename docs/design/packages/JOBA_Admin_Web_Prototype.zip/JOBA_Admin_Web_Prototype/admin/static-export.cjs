const fs=require('fs'),vm=require('vm'),path=require('path');
const root=__dirname;
let code=fs.readFileSync(path.join(root,'app.js'),'utf8').replace(/^render\(\);$/gm,'');
const ctx={document:{addEventListener:()=>{}},window:{addEventListener:()=>{}},URLSearchParams};vm.createContext(ctx);vm.runInContext(code,ctx);
const keys=process.argv.slice(2);if(!keys.length)keys.push(...vm.runInContext('Object.keys(routes)',ctx));
fs.mkdirSync(path.join(root,'static'),{recursive:true});
const override=`
@page{size:1440px 4000px;margin:0}
html,body{width:1440px;margin:0;min-height:1024px}
.shell{display:block;width:1440px;min-height:1024px;position:relative}
.sidebar{position:absolute;top:0;left:0;width:224px;height:1024px;display:block}
.brand{height:88px}.nav{height:850px;max-height:850px;overflow:hidden}.sidebarfoot{position:absolute;bottom:0;width:224px;height:68px;z-index:25;background:white}
.main{margin-left:224px;width:1216px;min-width:0}.workspace{max-width:none;padding:21px 32px 28px}.statebar{display:none}.statusbar{clear:both}
.topbar .right{width:360px;justify-content:flex-end}.topbar .account{min-width:170px}.topbar .account div{width:140px}.search{width:314px}.search kbd{white-space:nowrap}
.card,.note,.pagehead,.tablewrap,.grid{break-inside:avoid}.pagehead{margin-bottom:17px}.pagehead>div:first-child{flex:1;min-width:0}.pagehead h1{max-width:820px}
.cardhead{padding:14px 18px}.cardhead h2{flex:1;font-size:15px;white-space:nowrap}.cardbody{padding:16px 18px}.metric{padding:16px 18px}.metric-num{font-size:26px}.chart{height:155px}
.grid{gap:14px}.mt{margin-top:14px}.stack{display:block}.stack>*+*{margin-top:14px}.lineitem{padding:11px 0}.icon{max-width:18px;max-height:18px}
.render-button{display:inline-block;vertical-align:middle;border:1px solid #D9E1EC;border-radius:7px;padding:9px 13px;font-size:11px;background:#FFF;color:#172B4D;font-weight:700;line-height:18px;white-space:nowrap;text-align:center}
.render-button.primary{background:#245BDB;color:white;border-color:#245BDB}.render-button.danger{background:#FFF2F2;color:#A62634;border-color:#EABBC1}.render-button.small{padding:5px 9px;font-size:10px}.render-button .icon{vertical-align:middle;margin-right:6px}.render-button.switch{padding:2px;width:34px;height:20px;min-width:34px;border:0;display:inline-flex;vertical-align:middle;background:#B9C5D7;border-radius:15px}.render-button.switch.on{background:#245BDB}
.render-select,.render-input{display:block;border:1px solid #D9E1EC;border-radius:7px;padding:9px 11px;min-height:38px;background:#FFF;font-size:11px;line-height:18px;color:#172B4D}
.formfield{display:block;min-width:0;width:100%;text-align:left}.formfield label{display:block;margin-bottom:6px}.formfield small{display:block;margin-top:6px}.formfield .render-input,.formfield .render-select{width:100%;max-width:100%}.formgrid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px}.formgrid>*{min-width:0}.formgrid{display:block;width:100%;font-size:0}.formgrid>.formfield{display:inline-block;width:calc(50% - 8px);margin:0 12px 14px 0;vertical-align:top;font-size:11px}.formgrid>.formfield:nth-child(2n){margin-right:0}.formgrid>.formfield.wide{display:block;width:100%;margin-right:0}.render-button.mobile-nav{display:none}
.filters .render-input{flex:1;min-width:230px}.filters .render-select{min-width:150px}.filters .resultcount{white-space:nowrap}.cardbody>.row{width:100%}.row{min-width:0}.row>div{min-width:0}
.render-checkbox{display:inline-block;border:1px solid #A6B2C4;width:13px;height:13px;margin:0 7px 0 0;vertical-align:middle;background:white;border-radius:3px}.render-checkbox.checked{background:#245BDB;border-color:#245BDB;color:white;line-height:12px;font-size:10px;text-align:center}
textarea{display:block;width:100%;min-height:90px}.login{min-height:1024px;height:1024px}.loginform{margin-top:220px}.modalback{position:absolute;width:1440px;height:1024px}.drawer{position:absolute;height:1024px}.chatlayout{min-height:655px}.messages{display:block}.messages>.message{margin-bottom:16px}.message.support{margin-left:auto}.composer{margin-top:18px}
`;
for(const key of keys){const [route,state]=key.split('?state=');let html=vm.runInContext(`(()=>{let r=routes[${JSON.stringify(route)}];return r.key==='login'?r.body():shell(r,stateContent(${JSON.stringify(state||'default')},r))})()`,ctx);
html=html.replace(/<button([^>]*)>/g,(m,a)=>{if(/class="/.test(a))a=a.replace(/class="([^"]*)"/,'class="$1 render-button"');else a+=' class="render-button"';return '<span'+a+'>';}).replace(/<\/button>/g,'</span>');
html=html.replace(/<input([^>]*)>/g,(m,a)=>{if(/type="checkbox"/.test(a))return '<span class="render-checkbox '+(/checked/.test(a)?'checked':'')+'">'+(/checked/.test(a)?'✓':'')+'</span>';let v=(a.match(/value="([^"]*)"/)||[])[1]||(a.match(/placeholder="([^"]*)"/)||[])[1]||' ';return '<div class="render-input">'+v+'</div>';});
html=html.replace(/<select([^>]*)>([\s\S]*?)<\/select>/g,(m,a,b)=>'<div class="render-select">'+((b.match(/<option[^>]*selected[^>]*>(.*?)<\/option>/)||b.match(/<option[^>]*>(.*?)<\/option>/)||[])[1]||'')+' ▾</div>');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8').replaceAll("url('../assets/","url('../../assets/");
fs.writeFileSync(path.join(root,'static',key.replace('?state=','--')+'.html'),`<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>JOBA ${key}</title><style>${css}\n${override}</style></head><body>${html.replaceAll('../assets/','../../assets/')}</body></html>`);}
console.log(keys.length+' static frames exported');
