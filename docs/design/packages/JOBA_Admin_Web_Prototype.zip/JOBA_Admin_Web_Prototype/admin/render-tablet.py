from pathlib import Path
from weasyprint import HTML,CSS
import fitz,math,json,logging
logging.getLogger('weasyprint').setLevel(logging.ERROR)
r=Path(__file__).parent
css='''html,body,.shell{width:1024px!important}.sidebar{width:76px!important}.brand{padding:20px 17px}.brand img{width:40px;height:40px}.brand div,.navlabel,.nav a span,.nav .count,.sidebarfoot{display:none}.nav{padding:12px 10px;width:76px}.nav a{padding:12px 18px;width:56px}.nav a .icon{width:18px;height:18px}.main{margin-left:76px!important;width:948px!important}.topbar{padding:0 24px}.workspace{padding:23px 24px}.search{width:255px}.topbar .right{width:340px}.topbar .left{gap:12px}.cols4{grid-template-columns:repeat(2,1fr)}.split{grid-template-columns:1.4fr 1fr}.statusbar{padding:11px 24px}.cardhead h2{white-space:normal}.metric-num{font-size:25px}.sidebar{height:1024px}.tablewrap table{font-size:10px}td,th{padding-left:10px;padding-right:10px}.chatlayout{grid-template-columns:230px minmax(0,1fr)}.chatdetail{display:none}'''
report=[]
for key in ['dashboard','users']:
 name=key+'--tablet1024';s=(r/'static'/f'{key}.html').read_text().replace('</style>',css+'\n@page{size:1024px 4000px!important;margin:0}</style>');f=r/'static'/f'{name}.html';f.write_text(s)
 doc=HTML(filename=str(f),media_type='screen').render();bodies=[b for b in doc.pages[0]._page_box.descendants() if getattr(b,'element_tag',None)=='body'];height=max(1024,math.ceil(max(b.position_y+b.margin_height() for b in bodies)+12));out=r/'preview'/f'{name}.pdf';HTML(filename=str(f),media_type='screen').write_pdf(str(out),stylesheets=[CSS(string=f'@page{{size:1024px {height}px!important;margin:0}}')]);d=fitz.open(out);d[0].get_pixmap(matrix=fitz.Matrix(4/3,4/3)).save(r/'screens'/f'{name}_full.png');d[0].get_pixmap(matrix=fitz.Matrix(4/3,4/3),clip=fitz.Rect(0,0,768,768)).save(r/'screens'/f'{name}.png');report.append({'route':name,'viewport':[1024,1024],'fullstate':[1024,height],'pages':len(d)})
(r/'preview/render_report_tablet.json').write_text(json.dumps(report,indent=2));print(report)
