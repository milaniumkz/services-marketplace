from pathlib import Path
from weasyprint import HTML,CSS
import fitz,sys,json,logging,math
from PIL import Image,ImageDraw,ImageFont
logging.getLogger('weasyprint').setLevel(logging.ERROR)
root=Path(__file__).parent
names=sys.argv[1:] or ['dashboard','user-security','monetization'];report=[]
(root/'preview').mkdir(exist_ok=True);(root/'screens').mkdir(exist_ok=True)
for name in names:
 f=root/'static'/f'{name}.html';out=root/'preview'/f'{name}.pdf'
 doc=HTML(filename=str(f),media_type='screen').render()
 bodies=[b for b in doc.pages[0]._page_box.descendants() if getattr(b,'element_tag',None)=='body']
 bottom=max((b.position_y+b.margin_height() for b in bodies),default=1400)
 height=max(1024,min(4000,math.ceil(bottom+12)))
 # Preserve all content, then supply a separately named fixed viewport.
 HTML(filename=str(f),media_type='screen').write_pdf(str(out),stylesheets=[CSS(string=f'@page{{size:1440px {height}px!important;margin:0}}')])
 pdf=fitz.open(out);page=pdf[0]
 page.get_pixmap(matrix=fitz.Matrix(96/72,96/72)).save(root/'screens'/f'{name}_full.png')
 page.get_pixmap(matrix=fitz.Matrix(96/72,96/72),clip=fitz.Rect(0,0,1080,768)).save(root/'screens'/f'{name}.png')
 item={'route':name,'pages':len(pdf),'viewport':[1440,1024],'fullstate':[1440,height],'text_chars':sum(len(p.get_text()) for p in pdf),'method':'WeasyPrint static DOM; not browser QA','fullstate_png':f'screens/{name}_full.png','viewport_png':f'screens/{name}.png'};report.append(item);print(item)
(root/'preview/render_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
imgs=[Image.open(root/'screens'/f'{n}.png').convert('RGB') for n in names];out=Image.new('RGB',(1440,94+540*((len(imgs)+1)//2)),'#EAF0F8');d=ImageDraw.Draw(out);font=ImageFont.truetype(str(root.parent/'assets/fonts/NotoSans-Regular.ttf'),15);bold=ImageFont.truetype(str(root.parent/'assets/fonts/NotoSans-Bold.ttf'),27);d.text((32,18),'JOBA / ADMIN DESIGN · v1.1',fill='#172B4D',font=bold);d.text((32,56),'Static layout proof · viewport 1440×1024 · full-state files included',fill='#5B6B83',font=font)
for i,(n,img) in enumerate(zip(names,imgs)):
 img.thumbnail((680,484));x=30+(i%2)*710;y=94+(i//2)*540;out.paste(img,(x,y));d.text((x,y+img.height+10),n+' · viewport',fill='#405471',font=font)
out.save(root/'preview/contact-sheet.png')
