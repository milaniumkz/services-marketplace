from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json,sys
root=Path(__file__).parent
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--allow-file-access-from-files'])
 page=browser.new_page(viewport={'width':1440,'height':1024},device_scale_factor=1)
 names=sys.argv[1:] or ['dashboard','user-security','monetization']
 for name in names:
  page.goto((root/'index.html').as_uri()+'#'+name,wait_until='load');page.wait_for_timeout(250);page.evaluate('document.fonts.ready');page.screenshot(path=str(root/'screens'/f'{name.replace("?state=","--")}.png'),full_page=True)
 browser.close()
thumbs=[]
for name in names:
 img=Image.open(root/'screens'/f'{name.replace("?state=","--")}.png').convert('RGB');img.thumbnail((680,484));thumbs.append((name,img))
out=Image.new('RGB',(1440,74+530*((len(thumbs)+1)//2)),'#EAF0F8');d=ImageDraw.Draw(out);font=ImageFont.truetype(str(root.parent/'assets/fonts/NotoSans-Regular.ttf'),17);bold=ImageFont.truetype(str(root.parent/'assets/fonts/NotoSans-Bold.ttf'),28);d.text((32,20),'JOBA / ADMIN DESIGN • v1.1',fill='#172B4D',font=bold)
for i,(name,img) in enumerate(thumbs):
 x=30+(i%2)*710;y=82+(i//2)*530;out.paste(img,(x,y));d.text((x,y+img.height+10),name,fill='#405471',font=font)
out.save(root/'preview/contact-sheet.png')
print('Rendered',len(names),'frames')
