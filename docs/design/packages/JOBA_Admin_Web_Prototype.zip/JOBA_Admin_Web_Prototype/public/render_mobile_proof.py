from pathlib import Path
from weasyprint import HTML,CSS
import tinycss2,fitz,json,logging
logging.getLogger('weasyprint').setLevel(logging.ERROR)
p=Path(__file__).resolve().parent
css=(p/'public.css').read_text(); rules=tinycss2.parse_stylesheet(css,skip_whitespace=True,skip_comments=True)
mobile=[]
for r in rules:
 if r.type=='at-rule' and r.lower_at_keyword=='media' and 'max-width:800px' in tinycss2.serialize(r.prelude).replace(' ',''):
  mobile.append(tinycss2.serialize(r.content))
forced='\n'.join(mobile)+'\n@page{size:390px 2350px!important;margin:0}html,body{width:390px!important} .public-header .header-links{width:auto}.public-header .btn{width:auto}.btn{display:flex;width:max-content}.hero-actions .btn{width:100%}.brand-card{height:278px}.float-card.one{width:190px}.float-card.two{width:198px}.page-title{max-width:346px}.row.between{flex-wrap:wrap}.public-footer{width:390px}.header-links>a.btn{display:flex}.header-links{gap:0}.header-links a:not(.btn){display:none}.status-row .left{width:210px}'
report=[]
for id in ['W01','W02','W03','W04','W05']:
 # Last author stylesheet ensures the deliberately selected 390px breakpoint is used by the paged renderer.
 source=(p/'screens'/f'{id}.html').read_text().replace('</head>',f'<style>{forced}</style></head>')
 pdf=p/'previews'/f'{id}_mobile.pdf';HTML(string=source,base_url=str(p/'screens')+'/',media_type='screen').write_pdf(str(pdf))
 d=fitz.open(str(pdf));d[0].get_pixmap(matrix=fitz.Matrix(96/72,96/72),clip=fitz.Rect(0,0,292.5,633)).save(str(p/'previews'/f'{id}_mobile.png'))
 report.append({'id':id,'width':390,'height':844,'method':'WeasyPrint selected CSS breakpoint proof; not browser viewport QA','full_pages':len(d)})
 print(id,len(d))
(p/'previews'/'mobile_render_report.json').write_text(json.dumps(report,indent=2))
