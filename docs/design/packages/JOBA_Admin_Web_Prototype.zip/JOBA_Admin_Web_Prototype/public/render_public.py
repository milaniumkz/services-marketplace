from pathlib import Path
from weasyprint import HTML,CSS
import fitz,json,logging
logging.getLogger('weasyprint').setLevel(logging.ERROR)
p=Path(__file__).resolve().parent;report=[]
for id,height in [('W01',1120),('W02',1120),('W03',1400),('W04',1120),('W05',1360)]:
 f=p/'screens'/f'{id}.html';out=p/'previews'/f'{id}.pdf'
 HTML(filename=str(f)).write_pdf(str(out),stylesheets=[CSS(string=f'@page{{size:1440px {height}px!important;margin:0}}')])
 d=fitz.open(str(out));d[0].get_pixmap(matrix=fitz.Matrix(96/72,96/72)).save(str(p/'previews'/f'{id}_full.png'))
 d[0].get_pixmap(matrix=fitz.Matrix(96/72,96/72),clip=fitz.Rect(0,0,1080,768)).save(str(p/'previews'/f'{id}.png'))
 report.append({'id':id,'pages':len(d),'viewport':{'width':1440,'height':1024},'fullstate':{'width':1440,'height':height},'text_chars':sum(len(pg.get_text()) for pg in d),'method':'WeasyPrint static HTML proof; not Chromium browser screenshot'})
 print(id,len(d),'page(s)')
(p/'previews'/'render_report.json').write_text(json.dumps(report,indent=2))
