# JOBA - экраны автономного прототипа

Полные PNG отдельно: JOBA_Admin_Full_Screens.zip.

| ID | Экран | PNG | HTML | Prototype |
|---|---|---|---|---|
| A01 | Вход сотрудника | admin/screens/login.png | admin/static/login.html | admin/index.html#login |
| A02 | Дашборд и ad revenue | admin/screens/dashboard.png | admin/static/dashboard.html | admin/index.html#dashboard |
| A03 | Пользователи | admin/screens/users.png | admin/static/users.html | admin/index.html#users |
| A04 | Заказ и история | admin/screens/order-detail.png | admin/static/order-detail.html | admin/index.html#order-detail |
| A05 | Очередь модерации | admin/screens/moderation.png | admin/static/moderation.html | admin/index.html#moderation |
| A06 | Дело и апелляция | admin/screens/case.png | admin/static/case.html | admin/index.html#case |
| A07 | Проверка документов | admin/screens/verification.png | admin/static/verification.html | admin/index.html#verification |
| A08 | Категории и языки | admin/screens/categories.png | admin/static/categories.html | admin/index.html#categories |
| A09 | Планы цены и промо | admin/screens/pricing.png | admin/static/pricing.html | admin/index.html#pricing |
| A10 | Кампании | admin/screens/campaigns.png | admin/static/campaigns.html | admin/index.html#campaigns |
| A11 | Privacy очередь | admin/screens/privacy.png | admin/static/privacy.html | admin/index.html#privacy |
| A12 | Security события | admin/screens/security.png | admin/static/security.html | admin/index.html#security |
| A13 | Аудит | admin/screens/audit.png | admin/static/audit.html | admin/index.html#audit |
| A14 | Country capabilities | admin/screens/countries.png | admin/static/countries.html | admin/index.html#countries |
| A15 | Jobs и интеграции | admin/screens/jobs.png | admin/static/jobs.html | admin/index.html#jobs |
| A16 | Подписка и реклама | admin/screens/monetization.png | admin/static/monetization.html | admin/index.html#monetization |
| A17 | Push-кампании | admin/screens/push.png | admin/static/push.html | admin/index.html#push |
| A18 | Запрещенные слова | admin/screens/dictionary.png | admin/static/dictionary.html | admin/index.html#dictionary |
| A19 | Иконка приложения | admin/screens/branding.png | admin/static/branding.html | admin/index.html#branding |
| A20 | Реферальные кампании | admin/screens/referrals.png | admin/static/referrals.html | admin/index.html#referrals |
| A21 | Поддержка и recovery | admin/screens/support.png | admin/static/support.html | admin/index.html#support |
| A22 | Топ и продвижение | admin/screens/top100.png | admin/static/top100.html | admin/index.html#top100 |
| W01 | Описание продукта и страны | public/previews/W01.png | public/screens/W01.html | public/screens/W01.html |
| W02 | Поддержка | public/previews/W02.png | public/screens/W02.html | public/screens/W02.html |
| W03 | Правовые документы | public/previews/W03.png | public/screens/W03.html | public/screens/W03.html |
| W04 | Удаление аккаунта | public/previews/W04.png | public/screens/W04.html | public/screens/W04.html |
| W05 | Доступность и обслуживание | public/previews/W05.png | public/screens/W05.html | public/screens/W05.html |
